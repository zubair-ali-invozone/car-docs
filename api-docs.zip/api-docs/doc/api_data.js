define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./doc/main.js",
    "group": "/home/zubairali-invozone/Documents/Node/api-docs/doc/main.js",
    "groupTitle": "/home/zubairali-invozone/Documents/Node/api-docs/doc/main.js",
    "name": ""
  },
  {
    "group": "Car_Listing",
    "type": "get",
    "url": "/list-cars/:user_id/:token",
    "title": "Request available cars",
    "name": "RequestAvailableCars",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "user_id",
            "description": "<p>Users unique ID.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>Unique token for auth.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[\n { \"car_id\": \"1\", \"car_name\": \"Honda City\", \"car_modal\": \"2015\", \"rent_per_day\": 100, \"currency\": \"$\", \"img_url\": \"abc.png\"},\n { \"car_id\": \"2\", \"car_name\": \"Audi A6\", \"car_modal\": \"2018\", \"rent_per_day\": 300, \"currency\": \"$\", \"img_url\": \"abc.png\"},\n { \"car_id\": \"2\", \"car_name\": \"BMW X8\", \"car_modal\": \"2016\", \"rent_per_day\": 500, \"currency\": \"$\", \"img_url\": \"abc.png\"}\n]",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "CarNotFound",
            "description": "<p>If no car is available in the system.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Sorry! No car available in the system\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./example.js",
    "groupTitle": "Car_Listing"
  },
  {
    "type": "post",
    "url": "/book-cars",
    "title": "Request car booking",
    "name": "RequestCarsBooking",
    "group": "Cars_Booking",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "user_id",
            "description": "<p>Users unique ID.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "car_id",
            "description": "<p>Car unique ID.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "longitude",
            "description": "<p>Longitude for Location.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "latitude",
            "description": "<p>Latitude for Location.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "no_of_days",
            "description": "<p>No of days from car booking.</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "from_date",
            "description": "<p>Booking start date.</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "to_date",
            "description": "<p>Booking end date.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "_token",
            "description": "<p>jwt token for auth.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>Your car has booked successfully.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "car",
            "description": "<p>Audi A6.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "duration",
            "description": "<p>From 01-01-2021 to 05-01-2021.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "calculated_rent",
            "description": "<p>1500$.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n {\n \"msg\": \"Your car has booked successfully\",\n \"car\": \"Audi A6 2018\",\n \"calculated_rent\": \"1500$\",\n \"duration\": \"From 01-01-2021 to 05-01-2021\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "CarAlreadyBooked",
            "description": "<p>If selected car is already booked.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Sorry! Selected car is already booked, Please select another one.\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./example.js",
    "groupTitle": "Cars_Booking"
  },
  {
    "type": "post",
    "url": "/vendor_car_registration",
    "title": "Request for vendor car registration",
    "name": "RequestVendorCarsRegistration",
    "group": "Vendor_Registration",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "vendor_id",
            "description": "<p>Vendor unique ID after login.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "car_company_id",
            "description": "<p>Car company Unique ID.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "car_name",
            "description": "<p>Name of the car.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "car_color",
            "description": "<p>Color of the car.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "car_modal",
            "description": "<p>Car modal No.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "car_engine_no",
            "description": "<p>Car Engine No.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "car_no_plate",
            "description": "<p>Car Unique No.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "car_images",
            "description": "<p>Car Unique No.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "_token",
            "description": "<p>jwt token for auth.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>Your car has registered successfully.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n {\n \"msg\": \"Your car has registered successfully\",\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "Validation",
            "description": "<p>If required fields are empty or duplicate.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Engine No and Car No Plate already exist. Please use different No.\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./example.js",
    "groupTitle": "Vendor_Registration"
  }
] });

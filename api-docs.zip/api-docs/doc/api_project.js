define({
  "name": "Car Project",
  "version": "1.0.0",
  "description": "Car Register or Booking API Docs",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-05-05T10:35:27.575Z",
    "url": "https://apidocjs.com",
    "version": "0.27.1"
  }
});
